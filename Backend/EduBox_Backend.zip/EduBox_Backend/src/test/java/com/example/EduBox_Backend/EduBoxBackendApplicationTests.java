package com.example.EduBox_Backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EduBoxBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
